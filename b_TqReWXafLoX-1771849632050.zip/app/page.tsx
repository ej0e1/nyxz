"use client"

import { useState, useMemo } from "react"
import { Sidebar } from "@/components/dashboard/sidebar"
import { TopNav } from "@/components/dashboard/top-nav"
import { ContentArea } from "@/components/dashboard/content-area"
import { AddTorrentModal } from "@/components/dashboard/add-torrent-modal"
import { files as allFiles } from "@/lib/data"

export default function DashboardPage() {
  const [activeNav, setActiveNav] = useState("Dashboard")
  const [view, setView] = useState<"grid" | "list">("grid")
  const [searchQuery, setSearchQuery] = useState("")
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [torrentModalOpen, setTorrentModalOpen] = useState(false)

  const filteredFiles = useMemo(() => {
    if (!searchQuery.trim()) return allFiles
    const q = searchQuery.toLowerCase()
    return allFiles.filter((file) => file.name.toLowerCase().includes(q))
  }, [searchQuery])

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Sidebar */}
      <Sidebar
        activeItem={activeNav}
        onItemClick={setActiveNav}
        mobileOpen={mobileMenuOpen}
        onMobileClose={() => setMobileMenuOpen(false)}
      />

      {/* Main area */}
      <div className="flex flex-1 flex-col overflow-hidden">
        <TopNav
          onMobileMenuOpen={() => setMobileMenuOpen(true)}
          onUploadClick={() => {}}
          onAddTorrentClick={() => setTorrentModalOpen(true)}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />
        <ContentArea
          files={filteredFiles}
          view={view}
          onViewChange={setView}
        />
      </div>

      {/* Torrent Modal */}
      <AddTorrentModal
        open={torrentModalOpen}
        onClose={() => setTorrentModalOpen(false)}
      />
    </div>
  )
}
