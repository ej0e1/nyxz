"use client"

import { LayoutGrid, List } from "lucide-react"
import { cn } from "@/lib/utils"
import type { FileItem } from "@/lib/data"
import { FileCard } from "./file-card"

interface ContentAreaProps {
  files: FileItem[]
  view: "grid" | "list"
  onViewChange: (view: "grid" | "list") => void
}

export function ContentArea({ files, view, onViewChange }: ContentAreaProps) {
  const folders = files.filter((f) => f.isFolder)
  const fileItems = files.filter((f) => !f.isFolder)

  return (
    <main className="flex-1 overflow-y-auto p-4 sm:p-6">
      {/* View toggle + heading */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-foreground">My Files</h1>
          <p className="mt-0.5 text-sm text-muted-foreground">
            {files.length} items
          </p>
        </div>
        <div className="flex items-center gap-1 rounded-xl border border-border bg-card p-1">
          <button
            onClick={() => onViewChange("grid")}
            className={cn(
              "rounded-lg p-2 transition-all duration-200",
              view === "grid"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <LayoutGrid className="h-4 w-4" />
            <span className="sr-only">Grid view</span>
          </button>
          <button
            onClick={() => onViewChange("list")}
            className={cn(
              "rounded-lg p-2 transition-all duration-200",
              view === "list"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <List className="h-4 w-4" />
            <span className="sr-only">List view</span>
          </button>
        </div>
      </div>

      {/* Files empty state */}
      {files.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-secondary">
            <LayoutGrid className="h-8 w-8 text-muted-foreground" />
          </div>
          <p className="mt-4 text-sm font-medium text-foreground">
            No files found
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            Try adjusting your search query
          </p>
        </div>
      )}

      {/* Folders section */}
      {folders.length > 0 && (
        <section className="mb-8">
          <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Folders
          </h2>
          {view === "grid" ? (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4">
              {folders.map((folder) => (
                <FileCard key={folder.id} file={folder} view={view} />
              ))}
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              {folders.map((folder) => (
                <FileCard key={folder.id} file={folder} view={view} />
              ))}
            </div>
          )}
        </section>
      )}

      {/* Files section */}
      {fileItems.length > 0 && (
        <section>
          <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Files
          </h2>
          {view === "grid" ? (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4">
              {fileItems.map((file) => (
                <FileCard key={file.id} file={file} view={view} />
              ))}
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              {fileItems.map((file) => (
                <FileCard key={file.id} file={file} view={view} />
              ))}
            </div>
          )}
        </section>
      )}
    </main>
  )
}
