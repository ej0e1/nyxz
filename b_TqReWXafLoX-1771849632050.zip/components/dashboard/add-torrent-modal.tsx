"use client"

import { useState, useCallback } from "react"
import { X, Link as LinkIcon, Upload } from "lucide-react"

interface AddTorrentModalProps {
  open: boolean
  onClose: () => void
}

export function AddTorrentModal({ open, onClose }: AddTorrentModalProps) {
  const [magnetLink, setMagnetLink] = useState("")
  const [isDragging, setIsDragging] = useState(false)
  const [fileName, setFileName] = useState("")

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    const files = e.dataTransfer.files
    if (files.length > 0) {
      setFileName(files[0].name)
    }
  }, [])

  const handleFileSelect = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files
      if (files && files.length > 0) {
        setFileName(files[0].name)
      }
    },
    []
  )

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Dummy submit
    onClose()
    setMagnetLink("")
    setFileName("")
  }

  if (!open) return null

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-50 bg-foreground/20 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div
          className="w-full max-w-lg rounded-2xl border border-border bg-card p-6 shadow-xl"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-card-foreground">
              Add Torrent
            </h2>
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            >
              <X className="h-5 w-5" />
              <span className="sr-only">Close modal</span>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="mt-5 flex flex-col gap-5">
            {/* Magnet link */}
            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="magnet-link"
                className="text-sm font-medium text-foreground"
              >
                Magnet Link
              </label>
              <div className="relative">
                <LinkIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  id="magnet-link"
                  type="text"
                  placeholder="magnet:?xt=urn:btih:..."
                  value={magnetLink}
                  onChange={(e) => setMagnetLink(e.target.value)}
                  className="w-full rounded-xl border border-input bg-background py-2.5 pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground transition-all duration-200 focus:border-primary focus:outline-none focus:ring-2 focus:ring-ring/20"
                />
              </div>
            </div>

            {/* Divider */}
            <div className="flex items-center gap-3">
              <div className="h-px flex-1 bg-border" />
              <span className="text-xs text-muted-foreground">or</span>
              <div className="h-px flex-1 bg-border" />
            </div>

            {/* Drop zone */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed px-6 py-10 text-center transition-all duration-200 ${
                isDragging
                  ? "border-primary bg-primary/5"
                  : "border-border hover:border-primary/40 hover:bg-secondary/50"
              }`}
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-secondary">
                <Upload className="h-5 w-5 text-muted-foreground" />
              </div>
              {fileName ? (
                <p className="mt-3 text-sm font-medium text-foreground">
                  {fileName}
                </p>
              ) : (
                <>
                  <p className="mt-3 text-sm font-medium text-foreground">
                    Drop .torrent file here
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    or click to browse
                  </p>
                </>
              )}
              <input
                type="file"
                accept=".torrent"
                onChange={handleFileSelect}
                className="absolute inset-0 cursor-pointer opacity-0"
                style={{ position: "absolute" }}
              />
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-2.5 pt-1">
              <button
                type="button"
                onClick={onClose}
                className="rounded-xl border border-border bg-card px-4 py-2.5 text-sm font-medium text-foreground transition-all duration-200 hover:bg-accent active:scale-[0.98]"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!magnetLink && !fileName}
                className="rounded-xl bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground shadow-sm transition-all duration-200 hover:opacity-90 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
              >
                Add Torrent
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  )
}
